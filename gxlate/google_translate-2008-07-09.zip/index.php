<?php

require('googleTranslateTool.class.php');

// initiate the translator with the settings from english to spanish, for full language list check the main class file
$translator = new googleTranslateTool('en','es');

$result = $translator->translate_Text('Hello, this is a test of a translation');

if ( $result===false ) echo $translator->return_error();
else echo $result;

$result = $translator->translate_URL('http://www.yahoo.com/');

if ( $result===false ) echo $translator->return_error();
else echo $result;

?>